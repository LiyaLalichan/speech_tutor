from django.apps import AppConfig


class SpeechProcessingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'speech_processing'
